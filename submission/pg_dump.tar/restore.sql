--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 17.4 (Debian 17.4-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE orders;
--
-- Name: orders; Type: DATABASE; Schema: -; Owner: orders
--

CREATE DATABASE orders WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE orders OWNER TO orders;

\connect orders

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: components; Type: TABLE; Schema: public; Owner: orders
--

CREATE TABLE public.components (
    component_id integer NOT NULL,
    component_name character varying(64),
    system_name character varying(64)
);


ALTER TABLE public.components OWNER TO orders;

--
-- Name: components_component_id_seq; Type: SEQUENCE; Schema: public; Owner: orders
--

CREATE SEQUENCE public.components_component_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.components_component_id_seq OWNER TO orders;

--
-- Name: components_component_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orders
--

ALTER SEQUENCE public.components_component_id_seq OWNED BY public.components.component_id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: orders
--

CREATE TABLE public.orders (
    order_id integer NOT NULL,
    supplier_uuid character varying(36) NOT NULL,
    component_id integer,
    part_id integer,
    serial_no integer,
    comp_priority character varying(16),
    order_date timestamp without time zone,
    ordered_by integer,
    status character varying(16),
    status_date timestamp without time zone
);


ALTER TABLE public.orders OWNER TO orders;

--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: orders
--

CREATE SEQUENCE public.orders_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_order_id_seq OWNER TO orders;

--
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orders
--

ALTER SEQUENCE public.orders_order_id_seq OWNED BY public.orders.order_id;


--
-- Name: parts; Type: TABLE; Schema: public; Owner: orders
--

CREATE TABLE public.parts (
    part_id integer NOT NULL,
    manufacturer_id integer,
    part_no integer
);


ALTER TABLE public.parts OWNER TO orders;

--
-- Name: parts_part_id_seq; Type: SEQUENCE; Schema: public; Owner: orders
--

CREATE SEQUENCE public.parts_part_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parts_part_id_seq OWNER TO orders;

--
-- Name: parts_part_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orders
--

ALTER SEQUENCE public.parts_part_id_seq OWNED BY public.parts.part_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: orders
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    user_name character varying(32)
);


ALTER TABLE public.users OWNER TO orders;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: orders
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO orders;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orders
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: components component_id; Type: DEFAULT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.components ALTER COLUMN component_id SET DEFAULT nextval('public.components_component_id_seq'::regclass);


--
-- Name: orders order_id; Type: DEFAULT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.orders ALTER COLUMN order_id SET DEFAULT nextval('public.orders_order_id_seq'::regclass);


--
-- Name: parts part_id; Type: DEFAULT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.parts ALTER COLUMN part_id SET DEFAULT nextval('public.parts_part_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: components; Type: TABLE DATA; Schema: public; Owner: orders
--

COPY public.components (component_id, component_name, system_name) FROM stdin;
\.
COPY public.components (component_id, component_name, system_name) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: orders
--

COPY public.orders (order_id, supplier_uuid, component_id, part_id, serial_no, comp_priority, order_date, ordered_by, status, status_date) FROM stdin;
\.
COPY public.orders (order_id, supplier_uuid, component_id, part_id, serial_no, comp_priority, order_date, ordered_by, status, status_date) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: parts; Type: TABLE DATA; Schema: public; Owner: orders
--

COPY public.parts (part_id, manufacturer_id, part_no) FROM stdin;
\.
COPY public.parts (part_id, manufacturer_id, part_no) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: orders
--

COPY public.users (user_id, user_name) FROM stdin;
\.
COPY public.users (user_id, user_name) FROM '$$PATH$$/3398.dat';

--
-- Name: components_component_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orders
--

SELECT pg_catalog.setval('public.components_component_id_seq', 68, true);


--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orders
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 449, true);


--
-- Name: parts_part_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orders
--

SELECT pg_catalog.setval('public.parts_part_id_seq', 211, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orders
--

SELECT pg_catalog.setval('public.users_user_id_seq', 8, true);


--
-- Name: components components_component_name_key; Type: CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.components
    ADD CONSTRAINT components_component_name_key UNIQUE (component_name);


--
-- Name: components components_pkey; Type: CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.components
    ADD CONSTRAINT components_pkey PRIMARY KEY (component_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: orders orders_supplier_uuid_key; Type: CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_supplier_uuid_key UNIQUE (supplier_uuid);


--
-- Name: parts parts_manufacturer_id_part_no_key; Type: CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_manufacturer_id_part_no_key UNIQUE (manufacturer_id, part_no);


--
-- Name: parts parts_pkey; Type: CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_pkey PRIMARY KEY (part_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_user_name_key; Type: CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_user_name_key UNIQUE (user_name);


--
-- Name: orders orders_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.components(component_id) ON DELETE SET NULL;


--
-- Name: orders orders_ordered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_ordered_by_fkey FOREIGN KEY (ordered_by) REFERENCES public.users(user_id);


--
-- Name: orders orders_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orders
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(part_id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

